extends Node2D

func _ready():
	$UI/Label.text = "hi"
	$Button.disabled = false
