extends Node
var score = 0
func add_score(n):
	score += n
