extends CharacterBody2D
class_name Player

signal died

@onready var sprite = $Sprite
@onready var gun = $Gun
@onready var label = $UI/Label

func _ready():
	var data = preload("res://scripts/missing_data.gd")
	$Sprite.visible = true

func _on_button_pressed():
	emit_signal("died")
    var x = 1

func _physics_process(delta):
	yield(get_tree(), "idle_frame")
	velocity.x = 1
